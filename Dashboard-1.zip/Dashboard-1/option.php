<?php
session_start();
$dept_name_db=$_SESSION["dept_name"];
$username_db=$_SESSION["username"];
$dept_id_db=$_SESSION["dept_id"];
$field = $_GET["field"];

    $_SESSION["dept_name"]=$dept_name_db;
  $_SESSION["username"]=$username_db;
  $_SESSION["dept_id"]=$dept_id_db;

  if($_SESSION["dept_name"] && $_SESSION["username"] && $_SESSION["dept_id"])

{
  $_SESSION["dept_name"]=$dept_name_db;
  $_SESSION["username"]=$username_db;
  $_SESSION["dept_id"]=$dept_id_db;
  //echo "session validate";
}

?>
</html>
<!DOCTYPE html>
<html>
<head>
<title>faculity</title>
</head>
<link rel="shortcut icon" href="http://simbyone.com/_assets/favicon.ico">
<link rel="icon" type="image/vnd.microsoft.icon" href="http://simbyone.com/_assets/favicon.ico" />
<link rel="icon" href="http://simbyone.com/_assets/favicon.ico" type="image/x-icon" />

<title>30 Hover Effects For Buttons Demo</title>
<link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'>

<link href="_css/Icomoon/style.css" rel="stylesheet" type="text/css" />
<link href="_css/main.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript" src="_scripts/jquery-2.1.4.min.js"></script>



<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/action.css">
<script type="text/javascript" src="js/jquery.js"> </script>
        <script type="text/javascript" src="js/bootstrap.min.js" ></script>

<body>
  <div class="col-sm-8" id="div">
       <div class="wrapper-inner-tab-backgrounds">
<a href="insertfunction.php?field=<?php echo $field; ?>">
<div class="btn btn-primary" style="background-color:brown;margin-top:100px;margin-left:10%;width:200px;height:50px;padding-top:3px;background-color:#c68c53;font-family:andulus;font-size:27px;border: black">Insert</div></a>

<a href="listview.php?field=<?php echo $field; ?>">
  <div class="btn btn-primary"  style="background-color:brown;margin-top:100px;margin-left:15%;width:200px;height:50px;padding-top:3px; background-color: #c68c53;font-family:andulus;font-size:25px;border: black">Update</div>
</a>

</div>
    </div>

  </div>
  <!--<a href="logout.php">
<input type="submit" value="Logout" id="insert" style="margin-top: 40px;background-color:brown; border-radius:7px;font-size: 20px;color:white;font-family:andulus;border:black;"></a>-->
</body>
</html>