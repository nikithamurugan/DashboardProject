<?php
session_start();
require 'db.php';
global $username_db ,$password_db,$dept_id_db;
$username=$_POST["username"];
$password=$_POST["password"];
$str="select * from sce_admin where username='$username' AND password='$password'";
$result=@mysqli_query($con,$str);
while($row=@mysqli_fetch_array($result))
{
	$dept_id_db=$row["dept_id"];
	$username_db=$row["username"];
	$password_db=$row["password"];
}

$str1="select * from sce_department where dept_id='$dept_id_db'";
$result1=@mysqli_query($con,$str1);
while($row=@mysqli_fetch_array($result1))
{
	$dept_name_db=$row['dept_name'];
}
if(($username == $username_db) && ($password == $password_db))
{
	
$_SESSION["dept_name"]=$dept_name_db;
	$_SESSION["username"]=$username_db;
	$_SESSION["dept_id"]=$dept_id_db;

	header('location:view.php');
    exit();
}
else
{
	
	 echo "<script type=\"text/javascript\">window.alert('invalid username or password');
window.location.href = 'index.php';</script>";
	
   
}




?>