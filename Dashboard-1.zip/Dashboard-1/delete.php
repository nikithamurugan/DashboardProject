<?php
session_start();

require 'db.php';
$dept_name_db=$_SESSION["dept_name"];
$username_db=$_SESSION["username"];
$dept_id_db=$_SESSION["dept_id"];
$field = $_GET['field'];
$id=$_GET['id'];

    $_SESSION["dept_name"]=$dept_name_db;
	$_SESSION["username"]=$username_db;
	$_SESSION["dept_id"]=$dept_id_db;

	if($_SESSION["dept_name"] && $_SESSION["username"] && $_SESSION["dept_id"])

{
	$_SESSION["dept_name"]=$dept_name_db;
	$_SESSION["username"]=$username_db;
	$_SESSION["dept_id"]=$dept_id_db;
	//echo "session validate";
}

?>
<?php
if($field=="achievements")
{
$str="delete from sce_achievement where id='$id'";
}
elseif($field=="dept_details")
{
$str="delete from sce_department_details where id='$id'";
}
elseif($field=="lab")
{
$str="delete from sce_lab where id='$id'";
}
elseif($field=="rnd")
{
$str="delete from sce_rd where id='$id'";
}
elseif($field=="tieups")
{
$str="delete from sce_tieups where id='$id'";
}
elseif($field=="testimonials")
{
	$str="delete from sce_testimonials where id='$id'";
}
elseif($field=="faculty")
{
	$str="delete from sce_faculty_details where id='$id'";
}
elseif($field=="news_events")
{
	$str="delete from sce_newsandevents where id='$id'";
}
elseif($field=="facility")
{
	$str="delete from sce_facilities where id='$id'";
}
elseif($field=="advertisement")
{
	$str="delete from sce_advertisement where id='$id'";
}
$result=@mysqli_query($con,$str);
if($result)
{
	echo "<script type=\"text/javascript\">window.alert('Data deleted successfully');
window.location.href = 'listview.php?field=$field';</script>"; 
}
else
{
	echo "<script type=\"text/javascript\">window.alert('Error on deleting data');
window.location.href = 'listview.php?field=$field';</script>"; 
}
?>